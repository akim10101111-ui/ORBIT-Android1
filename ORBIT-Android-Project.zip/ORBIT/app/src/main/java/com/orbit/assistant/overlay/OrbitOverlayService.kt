package com.orbit.assistant.overlay

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.orbit.assistant.ai.GeminiClient
import kotlin.math.abs

class OrbitOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private val channel = "orbit_floating"
    private var latestScreenJpeg: ByteArray? = null
    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { intent?.getStringExtra("transcript")?.let { sendPrompt(it) } }
    }
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            latestScreenJpeg = intent?.getByteArrayExtra("screen_jpeg")
            (panel as? LinearLayout)?.getChildAt(2)?.let { (it as? TextView)?.text = "Screen captured. Ask ORBIT about what is visible." }
        }
    }
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        makeChannel()
        val n = Notification.Builder(this, channel).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("ORBIT is active").setContentText("Floating AI is ready").setOngoing(true).build()
        startForeground(42, n)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(voiceReceiver, IntentFilter("com.orbit.assistant.VOICE_RESULT"), RECEIVER_NOT_EXPORTED)
            registerReceiver(screenReceiver, IntentFilter("com.orbit.assistant.SCREEN_RESULT"), RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(voiceReceiver, IntentFilter("com.orbit.assistant.VOICE_RESULT"))
            @Suppress("DEPRECATION")
            registerReceiver(screenReceiver, IntentFilter("com.orbit.assistant.SCREEN_RESULT"))
        }
        createBubble()
    }
    private fun createBubble() {
        if (bubble != null) return
        val orb = FrameLayout(this).apply {
            contentDescription = "Open ORBIT assistant"
            isClickable = true
            isFocusable = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(48,48,57), Color.rgb(12,12,14))).apply { shape=GradientDrawable.OVAL; setStroke(3, Color.rgb(146,112,222)) }
            val mark = TextView(this@OrbitOverlayService).apply { text="✦"; textSize=27f; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
            addView(mark, FrameLayout.LayoutParams(-1,-1))
        }
        bubbleParams = WindowManager.LayoutParams(62,62,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18; y=250 }
        var downX=0f; var downY=0f; var startX=0; var startY=0; var dragged=false
        orb.setOnTouchListener { v,e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=bubbleParams.x; startY=bubbleParams.y; dragged=false; true }
                MotionEvent.ACTION_MOVE -> { if(abs(e.rawX-downX)>6 || abs(e.rawY-downY)>6) dragged=true; bubbleParams.x=startX+(downX-e.rawX).toInt(); bubbleParams.y=startY+(e.rawY-downY).toInt(); runCatching{wm.updateViewLayout(v,bubbleParams)}; true }
                MotionEvent.ACTION_UP -> { if(!dragged) openPanel(); true }
                else -> true
            }
        }
        bubble=orb; wm.addView(orb,bubbleParams)
    }
    private fun openPanel() {
        if(panel!=null) return
        bubble?.let { runCatching{wm.removeView(it)} }; bubble=null
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=shape(0xFF101012.toInt(),30,0xFF303036); setPadding(18,14,18,14) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val brand=TextView(this).apply { text="✦  ORBIT"; textSize=16f; setTextColor(Color.WHITE); letterSpacing=.12f }
        top.addView(brand,LinearLayout.LayoutParams(0,52,1f))
        val close=button("×",Color.WHITE,0xFF29292D) { closePanel() }; top.addView(close,LinearLayout.LayoutParams(44,44))
        root.addView(top)
        val voiceArea=FrameLayout(this).apply { minimumHeight=170 }
        val ring=TextView(this).apply { text="♩"; textSize=32f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=GradientDrawable().apply { shape=GradientDrawable.OVAL; setColor(0xFF19191C); setStroke(4,Color.rgb(111,139,225)) } }
        voiceArea.addView(ring,FrameLayout.LayoutParams(116,116,Gravity.CENTER))
        root.addView(voiceArea,LinearLayout.LayoutParams(-1,0,1f))
        val response=TextView(this).apply { text="Your conversation will appear here."; textSize=14f; setTextColor(0xFFB5B5BD.toInt()); setPadding(6,6,6,10); maxLines=8 }
        root.addView(response,LinearLayout.LayoutParams(-1,-2))
        val input=EditText(this).apply { hint="Ask me anything…"; setHintTextColor(0xFF77777F.toInt()); setTextColor(Color.WHITE); textSize=15f; minLines=1; maxLines=3; setPadding(14,12,14,12); background=shape(0xFF1B1B1F.toInt(),22,0xFF35353A) }
        root.addView(input,LinearLayout.LayoutParams(-1,-2))
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,8,0,0) }
        actions.addView(button("＋",Color.WHITE,0x00111111){Toast.makeText(this,"Attachments coming in the next update",Toast.LENGTH_SHORT).show()},LinearLayout.LayoutParams(44,44))
        actions.addView(button("◎",Color.WHITE,0x00111111){openWebSearch(input.text.toString())},LinearLayout.LayoutParams(44,44))
        actions.addView(button("⌖",Color.WHITE,0x00111111){startScreenCapture()},LinearLayout.LayoutParams(44,44))
        actions.addView(button("♩",Color.WHITE,0x00111111){startVoice()},LinearLayout.LayoutParams(44,44))
        actions.addView(button("➤",Color.BLACK,Color.WHITE){ val q=input.text.toString().trim(); if(q.isNotEmpty()){input.setText("");sendPrompt(q)} },LinearLayout.LayoutParams(48,48))
        root.addView(actions)
        val p=WindowManager.LayoutParams((resources.displayMetrics.widthPixels*.90f).toInt().coerceAtMost(560), (resources.displayMetrics.heightPixels*.58f).toInt().coerceAtLeast(420), overlayType(), WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y=32
            softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        panel=root; wm.addView(root,p)
    }
    private fun sendPrompt(prompt:String) {
        val p=panel as? LinearLayout ?: run { openPanel(); panel as? LinearLayout }
        val response=(p?.getChildAt(2) as? TextView) ?: return
        response.text="Thinking…"
        GeminiClient.reply(this,prompt,latestScreenJpeg) { answer -> response.post { response.text=answer; speak(answer) } }
    }
    private fun startScreenCapture() {
        runCatching { startActivity(Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(this,"Screen capture could not start",Toast.LENGTH_SHORT).show() }
    }
    private fun startVoice() { runCatching { startActivity(Intent(this,VoiceInputActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure { Toast.makeText(this,"Voice input couldn't start",Toast.LENGTH_SHORT).show() } }
    private fun openWebSearch(query:String) { val q=query.trim(); if(q.isBlank()) return; startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://www.google.com/search?q="+android.net.Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    private fun speak(text:String) { val i=Intent(this,VoiceInputActivity::class.java).putExtra("speak_text",text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); runCatching{startActivity(i)} }
    private fun closePanel() { panel?.let{runCatching{wm.removeView(it)}};panel=null;createBubble() }
    private fun button(text:String,fg:Int,bg:Int,onClick:()->Unit)=TextView(this).apply { this.text=text; textSize=20f; gravity=Gravity.CENTER; setTextColor(fg); background=GradientDrawable().apply{cornerRadius=24f;setColor(bg)}; setOnClickListener{onClick()} }
    private fun shape(fill:Int,r:Int,stroke:Int)=GradientDrawable().apply{cornerRadius=r.toFloat();setColor(fill);setStroke(1,stroke)}
    private fun overlayType()=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun makeChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"ORBIT floating assistant",NotificationManager.IMPORTANCE_LOW))}
    override fun onDestroy(){runCatching{unregisterReceiver(voiceReceiver)};runCatching{unregisterReceiver(screenReceiver)};latestScreenJpeg=null;bubble?.let{runCatching{wm.removeView(it)}};panel?.let{runCatching{wm.removeView(it)}};super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
