package com.orbit.assistant.ai

import android.content.Context
import com.orbit.assistant.OrbitPrefs
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/** Lightweight Gemini REST client. API key is sent in a header, not a URL. */
object GeminiClient {
    private const val MODEL = "gemini-2.5-flash"
    private const val API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    fun reply(context: Context, prompt: String, screenJpeg: ByteArray? = null, callback: (String) -> Unit) {
        val appContext = context.applicationContext
        Thread({
            val result = runCatching {
                val key = OrbitPrefs.getKey(appContext)
                if (key.isBlank()) return@runCatching "Add a Gemini API key in ORBIT settings to start chatting."
                val parts = JSONArray().put(JSONObject().put("text", prompt.trim()))
                if (screenJpeg != null) {
                    parts.put(JSONObject().put("inlineData", JSONObject()
                        .put("mimeType", "image/jpeg")
                        .put("data", Base64.getEncoder().encodeToString(screenJpeg))))
                }
                val instruction = "You are ORBIT, a concise, friendly Android AI companion. Reply in the user's language. " +
                    "If an image is provided, describe only visible evidence and be honest about uncertainty. " +
                    "Keep responses clear and useful; do not claim you can see live content unless an image was sent."
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction)))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", JSONObject().put("temperature", 0.65).put("maxOutputTokens", 900))
                val conn = (URL(API_ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", key)
                }
                try {
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (code !in 200..299) {
                        val detail = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                        when (code) {
                            400 -> "Gemini rejected the request. Check the prompt or image and try again. ${detail.orEmpty()}".trim()
                            401, 403 -> "Gemini API key is invalid or doesn't have access. Check your key in ORBIT settings."
                            429 -> "Gemini rate limit or quota reached. Wait a little and try again."
                            else -> "Gemini request failed (HTTP $code). ${detail.orEmpty()}".trim()
                        }
                    } else {
                        val partsOut = JSONObject(response).optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts")
                        (0 until (partsOut?.length() ?: 0)).mapNotNull { i ->
                            partsOut?.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }
                        }.joinToString("\n").ifBlank { "I didn't receive a text response." }
                    }
                } finally {
                    conn.disconnect()
                }
            }.getOrElse { error ->
                "Connection error: ${error.message?.take(180) ?: "Please check your internet connection and try again."}"
            }
            callback(result)
        }, "ORBIT-Gemini").apply { isDaemon = true }.start()
    }
}
