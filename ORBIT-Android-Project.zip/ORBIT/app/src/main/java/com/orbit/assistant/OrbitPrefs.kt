package com.orbit.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object OrbitPrefs {
    private const val FILE = "orbit_secure_settings"
    fun getKey(context: Context): String = runCatching { prefs(context).getString("gemini_key", "") ?: "" }.getOrDefault("")
    fun setKey(context: Context, key: String) { runCatching { prefs(context).edit().putString("gemini_key", key.trim()).apply() } }
    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context, FILE,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}
