package com.orbit.assistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orbit.assistant.overlay.OrbitOverlayService
import com.orbit.assistant.ui.OrbitMark

private val Void = Color(0xFF050506)
private val Panel = Color(0xFF111114)
private val Panel2 = Color(0xFF18181C)
private val Line = Color(0xFF28282E)
private val Soft = Color(0xFF9999A3)
private val Violet = Color(0xFF9A82EF)

class MainActivity : ComponentActivity() {
    private var overlayPermissionState: androidx.compose.runtime.MutableState<Boolean>? = null
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    override fun onResume() {
        super.onResume()
        overlayPermissionState?.value = Settings.canDrawOverlays(this)
    }
    private fun render() {
        setContent {
            val overlayAllowed = remember { mutableStateOf(Settings.canDrawOverlays(this)) }
            overlayPermissionState = overlayAllowed
            MaterialTheme(colorScheme = darkColorScheme(background=Void, surface=Panel, primary=Violet)) {
                OrbitHome(
                    overlayAllowed=overlayAllowed.value, apiKey=OrbitPrefs.getKey(this),
                    onKeyChange={ OrbitPrefs.setKey(this,it) },
                    onGrantOverlay={ startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
                    onStart={ if(Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OrbitOverlayService::class.java)) }
                )
            }
        }
    }
}


@Composable
private fun OrbitHome(overlayAllowed:Boolean, apiKey:String, onKeyChange:(String)->Unit, onGrantOverlay:()->Unit, onStart:()->Unit) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    var reveal by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Void).verticalScroll(rememberScrollState()).padding(horizontal=22.dp)) {
        Spacer(Modifier.height(34.dp))
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(46.dp).background(Panel2,CircleShape).border(1.dp,Line,CircleShape),contentAlignment=Alignment.Center){ OrbitMark(Modifier.size(30.dp)) }
            Column { Text("ORBIT",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold,letterSpacing=4.sp); Text("AI companion",color=Soft,fontSize=12.sp,letterSpacing=0.5.sp) }
            Spacer(Modifier.weight(1f))
            Box(Modifier.background(Color(0xFF13151A),RoundedCornerShape(30.dp)).border(1.dp,Line,RoundedCornerShape(30.dp)).padding(horizontal=12.dp,vertical=7.dp)) { Text("BETA",color=Color(0xFFB8A6F3),fontSize=10.sp,letterSpacing=1.6.sp,fontWeight=FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().height(290.dp).background(Brush.radialGradient(listOf(Color(0x333F61A8),Color(0x22261C46),Void))),contentAlignment=Alignment.Center) {
            Box(Modifier.size(212.dp).background(Brush.radialGradient(listOf(Color(0x221A9BFF),Color(0x101A1429),Color.Transparent)),CircleShape),contentAlignment=Alignment.Center) {
                Box(Modifier.size(154.dp).background(Color(0xFF0D0D10),CircleShape).border(1.dp,Color(0xFF34323F),CircleShape),contentAlignment=Alignment.Center) { OrbitMark(Modifier.size(100.dp)) }
            }
            Column(Modifier.align(Alignment.BottomCenter),horizontalAlignment=Alignment.Center) {
                Text("Intelligence, within reach.",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Medium)
                Spacer(Modifier.height(8.dp)); Text("Ask. See. Understand.",color=Soft,fontSize=14.sp)
            }
        }
        Spacer(Modifier.height(22.dp))
        Surface(color=Panel,shape=RoundedCornerShape(26.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("FLOATING ASSISTANT",color=Soft,fontSize=11.sp,letterSpacing=1.7.sp,fontWeight=FontWeight.SemiBold)
                Text(if(overlayAllowed) "Ready to float" else "One permission away",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.SemiBold)
                Text("Keep ORBIT above your apps. Tap the star to open a compact chat, speak naturally, or ask it to understand your screen.",color=Soft,fontSize=13.sp,lineHeight=19.sp)
                Button(onClick=if(overlayAllowed) onStart else onGrantOverlay,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Color.Black)) {
                    Text(if(overlayAllowed) "Start ORBIT" else "Enable floating access",fontWeight=FontWeight.SemiBold); Spacer(Modifier.width(8.dp)); Icon(Icons.Rounded.ArrowForward,null)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            FeatureTile("Screen vision", "Analyze what you see", Icons.Rounded.Visibility, Modifier.weight(1f))
            FeatureTile("Voice", "Talk naturally", Icons.Rounded.Mic, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Surface(color=Panel,shape=RoundedCornerShape(24.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) { Text("AI connection",color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=16.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.Waves,null,tint=Violet) }
                Text("Gemini",color=Color(0xFFB8A6F3),fontSize=12.sp,fontWeight=FontWeight.Medium)
                OutlinedTextField(value=key,onValueChange={key=it;onKeyChange(it)},modifier=Modifier.fillMaxWidth(),label={Text("API key")},placeholder={Text("Paste Gemini key")},singleLine=true,visualTransformation=if(reveal) VisualTransformation.None else PasswordVisualTransformation(),trailingIcon={TextButton(onClick={reveal=!reveal}){Text(if(reveal)"Hide" else "Show",color=Soft)}},colors=OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White,unfocusedTextColor=Color.White,focusedBorderColor=Violet,unfocusedBorderColor=Line,focusedLabelColor=Violet,unfocusedLabelColor=Soft))
                Text("Your key is stored encrypted on this device.",color=Soft,fontSize=11.sp)
                TextButton(onClick={key="";onKeyChange("")}){Text("Remove API key",color=Color(0xFFB7B7C0))}
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Privacy first · Screen capture starts only when you request it and approve Android's prompt.",color=Color(0xFF66666F),fontSize=11.sp,lineHeight=16.sp)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FeatureTile(title:String,subtitle:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier) {
    Surface(modifier, color=Panel,shape=RoundedCornerShape(22.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Line)) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Icon(icon,null,tint=Violet); Text(title,color=Color.White,fontWeight=FontWeight.Medium,fontSize=14.sp); Text(subtitle,color=Soft,fontSize=11.sp,lineHeight=14.sp) }
    }
}
