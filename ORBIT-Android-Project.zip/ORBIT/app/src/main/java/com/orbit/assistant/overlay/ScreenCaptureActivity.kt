package com.orbit.assistant.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.widget.Toast
import java.io.ByteArrayOutputStream

/** One-shot user-approved screen snapshot. No continuous recording. */
class ScreenCaptureActivity : Activity() {
    private val requestCode = 918
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
    }
    @Deprecated("Android permission result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != this.requestCode || resultCode != RESULT_OK || data == null) { finish(); return }
        runCatching { capture(resultCode, data) }.onFailure { Toast.makeText(this,"Could not capture screen",Toast.LENGTH_SHORT).show(); finish() }
    }
    private fun capture(resultCode:Int, data:Intent) {
        val projectionManager=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection=projectionManager.getMediaProjection(resultCode,data)
        val metrics=resources.displayMetrics
        val reader=ImageReader.newInstance(metrics.widthPixels,metrics.heightPixels,PixelFormat.RGBA_8888,2)
        var display:VirtualDisplay?=null
        display=projection.createVirtualDisplay("ORBIT snapshot",metrics.widthPixels,metrics.heightPixels,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.surface,null,Handler(Looper.getMainLooper()))
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val image=reader.acquireLatestImage()
                if(image==null) { Toast.makeText(this,"No screen frame received",Toast.LENGTH_SHORT).show() }
                else {
                    val plane=image.planes[0]; val buffer=plane.buffer; val pixelStride=plane.pixelStride; val rowStride=plane.rowStride; val rowPadding=rowStride-pixelStride*metrics.widthPixels
                    val raw=Bitmap.createBitmap(metrics.widthPixels+rowPadding/pixelStride,metrics.heightPixels,Bitmap.Config.ARGB_8888)
                    raw.copyPixelsFromBuffer(buffer)
                    val bitmap=Bitmap.createBitmap(raw,0,0,metrics.widthPixels,metrics.heightPixels)
                    val scaled=Bitmap.createScaledBitmap(bitmap, minOf(bitmap.width,1080), (bitmap.height*minOf(bitmap.width,1080).toFloat()/bitmap.width).toInt(),true)
                    val bytes=ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG,78,it) }.toByteArray()
                    sendBroadcast(Intent("com.orbit.assistant.SCREEN_RESULT").setPackage(packageName).putExtra("screen_jpeg",bytes))
                    image.close(); raw.recycle(); bitmap.recycle(); scaled.recycle()
                    Toast.makeText(this,"Screen snapshot ready for ORBIT",Toast.LENGTH_SHORT).show()
                }
            } catch (_:Throwable) { Toast.makeText(this,"Screen capture failed",Toast.LENGTH_SHORT).show() }
            finally { reader.close(); display?.release(); projection.stop(); finish() }
        },500)
    }
}
