package com.orbit.assistant.overlay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

class VoiceInputActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val speakText=intent.getStringExtra("speak_text")
        if(!speakText.isNullOrBlank()) { tts=TextToSpeech(this,this); return }
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 7); return }
        if(!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this,"Speech recognition is unavailable on this device",Toast.LENGTH_LONG).show();finish();return }
        val recognizer=SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object:android.speech.RecognitionListener {
            override fun onReadyForSpeech(params:Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms:Float) {}
            override fun onBufferReceived(buffer:ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error:Int) { Toast.makeText(this@VoiceInputActivity,"Voice input error ($error)",Toast.LENGTH_SHORT).show();finish() }
            override fun onResults(results:Bundle?) { val text=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if(!text.isNullOrBlank()) sendBroadcast(Intent("com.orbit.assistant.VOICE_RESULT").setPackage(packageName).putExtra("transcript",text)); finish() }
            override fun onPartialResults(partialResults:Bundle?) {}
            override fun onEvent(eventType:Int,params:Bundle?) {}
        })
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()).putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to ORBIT")
        recognizer.startListening(intent)
    }
    override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS){ tts?.language=Locale.getDefault(); tts?.setOnUtteranceProgressListener(object:android.speech.tts.UtteranceProgressListener(){ override fun onStart(utteranceId:String?){} override fun onDone(utteranceId:String?){runOnUiThread{finish()}} override fun onError(utteranceId:String?){runOnUiThread{finish()}} }); tts?.speak(intent.getStringExtra("speak_text"),TextToSpeech.QUEUE_FLUSH,null,"orbit_reply")}else finish() }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==7&&grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED){recreate()}else finish()}
    override fun onDestroy(){speechRecognizer?.cancel();speechRecognizer?.destroy();speechRecognizer=null;tts?.stop();tts?.shutdown();super.onDestroy()}
}
