# ORBIT — floating AI companion for Android

ORBIT is an Android prototype for a compact AI assistant that can be opened above other apps. The visual direction is black, minimal, rounded, with a luminous star mark and a bottom dock inspired by the supplied reference screenshots.

## Project status

**Prototype / not release-ready.** The project has not been built on an Android SDK in this workspace, and a real-device test has not been performed. The GitHub Actions workflow is included to compile a Debug APK after the project is pushed.

### Current features in source
- Kotlin Android app with Jetpack Compose settings/home screen.
- Custom ORBIT star mark and launcher icon vector.
- Movable floating assistant overlay using `WindowManager`.
- Compact panel with text prompt, browser search, screen-capture request, voice input and send action.
- Gemini REST client for text and optional captured JPEG context.
- Encrypted local storage for the API key using AndroidX Security Crypto.
- Android system speech recognition and Text-to-Speech.
- One-shot screen capture flow that requires the Android system consent dialog.
- GitHub Actions workflow to build and upload a Debug APK artifact.

## Known limitations / follow-up
- MediaProjection behavior and permissions must be verified on Android 8–15+, especially Android 14+ foreground-service requirements.
- Voice recognizer availability, locale, and permission behavior vary by device.
- Screen capture currently sends the latest captured image with the next prompt; it is not live video analysis.
- Direct API-key usage in an APK is suitable only for a personal prototype. A public app should use a backend proxy with rate limits, abuse protection, and provider-secret management.
- The floating panel is a native overlay and needs visual/device testing for cutouts, gesture navigation, keyboard resize, landscape, and accessibility sizes.
- The project requires an Android SDK/Gradle environment to compile. No APK is included until CI or local Android Studio successfully builds it.

## Requirements
- Android Studio (recent stable)
- JDK 17
- Android SDK Platform 35 and Build Tools compatible with AGP 8.7.3
- Internet access to resolve Gradle dependencies

## Build locally
1. Open the project folder in Android Studio.
2. Allow Gradle sync to download dependencies.
3. Run on a physical Android device (overlay and screen-capture features are best tested on-device).
4. Create a Gemini API key from Google AI Studio, then paste it in ORBIT settings.
5. Grant the app's **Display over other apps** permission and start the floating service.
6. Use the screen-capture button and approve the Android system dialog before asking about the screen.
7. Build a Debug APK with **Build → Build APK(s)**.

Command-line build, if Gradle 8.9 and Android SDK are installed:

```bash
gradle --no-daemon assembleDebug
```

## GitHub setup
Suggested repository name: **ORBIT-Android**

Suggested description:
> A minimal floating AI assistant for Android with a movable orb, compact overlay chat, voice input, and user-approved screen context.

Suggested topics: `android`, `kotlin`, `jetpack-compose`, `ai-assistant`, `floating-overlay`, `gemini`, `screen-capture`, `voice-assistant`

Recommended visibility: Public, if you are comfortable sharing the source. Do not commit API keys, signing keys, local.properties, or personal data.

## CI artifact
The workflow at `.github/workflows/android-ci.yml` runs on pushes, pull requests, and manual dispatch. If it succeeds, GitHub Actions stores `app-debug.apk` as a downloadable artifact named **ORBIT-debug-apk** for 14 days.

## License
MIT. See `LICENSE`.
