package com.orbit.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Device-local preferences. The API key is encrypted at rest and never written to logs. */
object OrbitPrefs {
    private const val FILE = "orbit_secure_settings"
    private const val KEY_GEMINI = "gemini_key"

    fun getKey(context: Context): String = runCatching {
        preferences(context).getString(KEY_GEMINI, "").orEmpty()
    }.getOrDefault("")

    fun setKey(context: Context, value: String): Boolean = runCatching {
        preferences(context).edit().putString(KEY_GEMINI, value.trim()).apply()
        true
    }.getOrDefault(false)

    private fun preferences(context: Context) = EncryptedSharedPreferences.create(
        context.applicationContext,
        FILE,
        MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}
