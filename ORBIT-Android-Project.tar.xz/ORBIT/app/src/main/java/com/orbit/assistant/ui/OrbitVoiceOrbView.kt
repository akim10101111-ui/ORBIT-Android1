package com.orbit.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/** Animated microphone ring inspired by the user's reference panel. */
class OrbitVoiceOrbView(context: Context, private val onTap: () -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var rotation = 0f
    private var animator: ValueAnimator? = null

    init {
        contentDescription = "Start voice conversation with ORBIT"
        isClickable = true
        isFocusable = true
        setOnClickListener { onTap() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 6200L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { rotation = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val radius = side * .39f

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, side * .49f,
            intArrayOf(0x222C9BCB, 0x142C2460, 0x00000000), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, side * .49f, paint)

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        paint.shader = SweepGradient(cx, cy,
            intArrayOf(0xFF5AC8EF.toInt(), 0xFF8B75F1.toInt(), 0xFFE08AEF.toInt(), 0xFF6DBBEA.toInt()), null)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = side * .035f
        paint.strokeCap = Paint.Cap.ROUND
        canvas.drawCircle(cx, cy, radius, paint)
        canvas.restore()

        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = 0xFF19191E.toInt()
        canvas.drawCircle(cx, cy, radius - side * .035f, paint)

        val white = 0xFFECECF1.toInt()
        paint.color = white
        paint.strokeWidth = side * .021f
        paint.strokeCap = Paint.Cap.ROUND
        paint.style = Paint.Style.STROKE
        val mic = RectF(cx - side * .065f, cy - side * .13f, cx + side * .065f, cy + side * .095f)
        canvas.drawRoundRect(mic, side * .065f, side * .065f, paint)
        val stem = RectF(cx - side * .12f, cy - side * .015f, cx + side * .12f, cy + side * .21f)
        canvas.drawArc(stem, 0f, 180f, false, paint)
        canvas.drawLine(cx, cy + side * .21f, cx, cy + side * .275f, paint)
        canvas.drawLine(cx - side * .085f, cy + side * .275f, cx + side * .085f, cy + side * .275f, paint)
        paint.style = Paint.Style.FILL
        paint.color = white
    }
}
