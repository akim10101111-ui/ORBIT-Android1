package com.orbit.assistant.overlay

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import java.io.ByteArrayOutputStream

/** Lets the user select one image and attach a small JPEG context to the next prompt. */
class ImageAttachmentActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQUEST_IMAGE)
        }.onFailure {
            Toast.makeText(this, "No image picker is available", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("System document picker result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_IMAGE) { finish(); return }
        val uri: Uri? = data?.data
        if (resultCode != RESULT_OK || uri == null) { finish(); return }
        runCatching {
            contentResolver.openInputStream(uri).use { input ->
                val stream = requireNotNull(input) { "Couldn't read the selected image" }
                val original = BitmapFactory.decodeStream(stream) ?: error("Unsupported image format")
                try {
                    val targetWidth = minOf(original.width, 1280)
                    val targetHeight = (original.height * targetWidth.toFloat() / original.width).toInt().coerceAtLeast(1)
                    val resized = if (targetWidth == original.width) original else Bitmap.createScaledBitmap(original, targetWidth, targetHeight, true)
                    try {
                        val bytes = ByteArrayOutputStream().use { stream ->
                            resized.compress(Bitmap.CompressFormat.JPEG, 82, stream)
                            stream.toByteArray()
                        }
                        sendBroadcast(Intent(OrbitEvents.ACTION_IMAGE_RESULT).setPackage(packageName)
                            .putExtra(OrbitEvents.EXTRA_SCREEN_JPEG, bytes))
                        Toast.makeText(this, "Image attached to ORBIT", Toast.LENGTH_SHORT).show()
                    } finally { if (resized !== original) resized.recycle() }
                } finally { original.recycle() }
            }
        }.onFailure {
            Toast.makeText(this, "Couldn't attach image: ${it.localizedMessage ?: "unsupported file"}", Toast.LENGTH_LONG).show()
        }
        finish()
    }

    companion object { private const val REQUEST_IMAGE = 702 }
}
