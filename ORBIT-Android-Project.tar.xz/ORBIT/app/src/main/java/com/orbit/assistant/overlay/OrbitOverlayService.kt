package com.orbit.assistant.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.pm.ServiceInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.speech.tts.TextToSpeech
import java.util.Locale
import com.orbit.assistant.ai.GeminiClient
import com.orbit.assistant.ui.OrbitMarkView
import com.orbit.assistant.ui.OrbitVoiceOrbView
import kotlin.math.abs

/** User-started assistant bubble and compact bottom sheet displayed over other apps. */
class OrbitOverlayService : Service(), TextToSpeech.OnInitListener {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var responseView: TextView? = null
    private var promptInput: EditText? = null
    private var statusView: TextView? = null
    private var latestImageJpeg: ByteArray? = null
    private var sending = false
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                OrbitEvents.ACTION_VOICE_RESULT -> {
                    val text = intent.getStringExtra(OrbitEvents.EXTRA_TRANSCRIPT).orEmpty()
                    if (text.isNotBlank()) {
                        if (panel == null) openPanel()
                        promptInput?.setText(text)
                        submitPrompt(text)
                    }
                }
                OrbitEvents.ACTION_SCREEN_RESULT, OrbitEvents.ACTION_IMAGE_RESULT -> {
                    latestImageJpeg = intent.getByteArrayExtra(OrbitEvents.EXTRA_SCREEN_JPEG)
                    statusView?.text = if (intent.action == OrbitEvents.ACTION_SCREEN_RESULT) "Screen snapshot ready · tap Send" else "Image attached · tap Send"
                    if (panel == null) openPanel()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startAsForeground()
        textToSpeech = TextToSpeech(this, this)
        registerLocalReceivers()
        createBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val openApp = PendingIntent.getActivity(
            this, 1, Intent(this, com.orbit.assistant.MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, OrbitOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ORBIT is ready")
            .setContentText("Tap the floating star to ask your assistant")
            .setContentIntent(openApp)
            .addAction(Notification.Action.Builder(null, "Stop ORBIT", stopIntent).build())
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun registerLocalReceivers() {
        val filter = IntentFilter().apply {
            addAction(OrbitEvents.ACTION_VOICE_RESULT)
            addAction(OrbitEvents.ACTION_SCREEN_RESULT)
            addAction(OrbitEvents.ACTION_IMAGE_RESULT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    private fun createBubble() {
        if (bubble != null || !android.provider.Settings.canDrawOverlays(this)) return
        val size = dp(58)
        val orb = FrameLayout(this).apply {
            contentDescription = "Open ORBIT AI assistant"
            isClickable = true
            isFocusable = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(59, 54, 84), Color.rgb(16, 16, 21))).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(1), Color.rgb(151, 125, 220))
            }
            addView(OrbitMarkView(this@OrbitOverlayService), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            elevation = dp(12).toFloat()
        }
        val params = WindowManager.LayoutParams(
            size, size, overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(220)
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragged = false
        orb.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y; dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) dragged = true
                    params.x = (startX - dx.toInt()).coerceAtLeast(0)
                    params.y = (startY + dy.toInt()).coerceAtLeast(dp(8))
                    runCatching { windowManager.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) openPanel()
                    true
                }
                else -> true
            }
        }
        bubbleParams = params
        bubble = orb
        runCatching { windowManager.addView(orb, params) }.onFailure {
            bubble = null
            Toast.makeText(this, "ORBIT couldn't display its floating button. Check overlay permission.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun openPanel() {
        if (panel != null) return
        removeBubble()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(14, 14, 18), dp(30), Color.rgb(53, 49, 65))
            setPadding(dp(17), dp(13), dp(17), dp(14))
            elevation = dp(18).toFloat()
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = FrameLayout(this).apply {
            background = rounded(Color.rgb(29, 27, 38), dp(15), Color.rgb(65, 59, 83))
            addView(OrbitMarkView(this@OrbitOverlayService), FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)))
        val brandColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
            addView(label("ORBIT", 15f, Color.WHITE, true))
            addView(label("YOUR AI COMPANION", 8f, Color.rgb(143, 140, 156), true))
        }
        top.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val minimize = actionButton("−", 42) { closePanel() }
        top.addView(minimize, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(top)

        val hero = FrameLayout(this).apply { minimumHeight = dp(126) }
        val voiceOrb = OrbitVoiceOrbView(this) { startVoiceInput() }
        hero.addView(voiceOrb, FrameLayout.LayoutParams(dp(126), dp(126), Gravity.CENTER))
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(142)))

        val status = label("Ready when you are.", 12f, Color.rgb(168, 165, 178), false).apply {
            setPadding(dp(2), dp(3), dp(2), dp(6))
        }
        statusView = status
        root.addView(status)

        val response = label("Ask about what you're watching, reading or doing. Capture the screen when you want ORBIT to see it.", 13f, Color.rgb(225, 224, 232), false).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(24, 24, 30), dp(18), Color.rgb(43, 42, 51))
            gravity = Gravity.CENTER_VERTICAL
            minHeight = dp(76)
        }
        responseView = response
        val responseScroll = ScrollView(this).apply { isFillViewport = false; addView(response) }
        root.addView(responseScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val input = EditText(this).apply {
            hint = "Ask me anything…"
            setHintTextColor(Color.rgb(126, 124, 136))
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 1
            maxLines = 3
            setPadding(dp(14), dp(11), dp(12), dp(11))
            background = rounded(Color.rgb(25, 25, 31), dp(22), Color.rgb(55, 53, 64))
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                    val text = this.text.toString().trim()
                    if (text.isNotEmpty()) submitPrompt(text)
                    true
                } else false
            }
        }
        promptInput = input
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, 0)
        }
        actions.addView(actionButton("＋", 42) { startImagePicker() }, weightedAction())
        actions.addView(actionButton("◎", 42) { searchWeb(input.text.toString()) }, weightedAction())
        actions.addView(actionButton("⌖", 42) { startScreenCapture() }, weightedAction())
        actions.addView(actionButton("♩", 42) { startVoiceInput() }, weightedAction())
        actions.addView(actionButton("↑", 46, true) {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                submitPrompt(text)
            } else Toast.makeText(this, "Type or say a question first", Toast.LENGTH_SHORT).show()
        }, weightedAction())
        root.addView(actions)

        val width = (resources.displayMetrics.widthPixels * 0.93f).toInt().coerceAtMost(dp(560))
        val height = (resources.displayMetrics.heightPixels * 0.66f).toInt().coerceAtLeast(dp(390))
        val params = WindowManager.LayoutParams(
            width, height, overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(18)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        }
        panel = root
        runCatching { windowManager.addView(root, params) }.onFailure {
            panel = null
            statusView = null; responseView = null; promptInput = null
            createBubble()
            Toast.makeText(this, "ORBIT panel couldn't open: ${it.localizedMessage ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun submitPrompt(prompt: String) {
        if (sending) {
            Toast.makeText(this, "ORBIT is still responding. Please wait.", Toast.LENGTH_SHORT).show()
            return
        }
        if (panel == null) openPanel()
        val response = responseView ?: return
        sending = true
        statusView?.text = if (latestImageJpeg != null) "Analyzing your image…" else "Thinking…"
        response.text = "ORBIT is preparing your answer…"
        val image = latestImageJpeg
        latestImageJpeg = null // attach the captured frame to one request only
        GeminiClient.reply(this, prompt, image) { answer ->
            sending = false
            if (responseView != null) {
                responseView?.text = answer
                statusView?.text = if (answer.startsWith("No internet") || answer.startsWith("Network") || answer.startsWith("The connection")) "Connection issue" else "ORBIT RESPONSE"
            }
            if (panel != null) speakAnswer(answer)
        }
    }

    private fun startScreenCapture() {
        runCatching { startActivity(Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(this, "Couldn't open Android screen-capture permission: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
    }

    private fun startVoiceInput() {
        runCatching { startActivity(Intent(this, VoiceInputActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(this, "Couldn't start voice input: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
    }

    private fun startImagePicker() {
        runCatching { startActivity(Intent(this, ImageAttachmentActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(this, "Couldn't open image picker", Toast.LENGTH_SHORT).show() }
    }

    private fun searchWeb(query: String) {
        val text = query.trim()
        if (text.isBlank()) {
            Toast.makeText(this, "Enter a search query first", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            val uri = android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(text))
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { Toast.makeText(this, "No browser is available to open the search", Toast.LENGTH_LONG).show() }
    }

    private fun speakAnswer(text: String) {
        if (ttsReady) {
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "orbit_reply_${System.currentTimeMillis()}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = textToSpeech ?: return
            val languageStatus = engine.setLanguage(Locale.getDefault())
            ttsReady = languageStatus != TextToSpeech.LANG_MISSING_DATA && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) engine.setLanguage(Locale.US)
        }
    }

    private fun closePanel() {
        panel?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        responseView = null; promptInput = null; statusView = null
        createBubble()
    }

    private fun removeBubble() {
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun actionButton(text: String, size: Int, primary: Boolean = false, action: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = if (primary) 22f else 20f
        gravity = Gravity.CENTER
        setTextColor(if (primary) Color.BLACK else Color.WHITE)
        background = rounded(if (primary) Color.WHITE else Color.rgb(31, 30, 38), dp(17), if (primary) Color.WHITE else Color.rgb(56, 53, 67))
        isClickable = true
        isFocusable = true
        contentDescription = when (text) {
            "＋" -> "Attach image"
            "◎" -> "Search the web"
            "⌖" -> "Analyze current screen"
            "♩" -> "Voice input"
            "↑" -> "Send message"
            else -> "Minimize ORBIT"
        }
        setOnClickListener { action() }
    }

    private fun weightedAction() = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) }
    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = radius.toFloat(); setColor(fill); setStroke(dp(1), stroke)
    }
    private fun overlayWindowType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "ORBIT floating assistant", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        removeBubble()
        panel?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        latestImageJpeg = null
        runCatching { textToSpeech?.stop(); textToSpeech?.shutdown() }
        textToSpeech = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "orbit_floating"
        private const val NOTIFICATION_ID = 42
        private const val ACTION_STOP = "com.orbit.assistant.action.STOP_OVERLAY"
    }
}
