package com.orbit.assistant.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Shows Android's mandatory consent dialog for one screen snapshot. */
class ScreenCaptureActivity : Activity() {
    private var requested = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState?.getBoolean(STATE_REQUESTED) == true || requested) {
            finish()
            return
        }
        requested = true
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        runCatching { startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE) }
            .onFailure {
                Toast.makeText(this, "Android couldn't open screen capture permission: ${it.localizedMessage}", Toast.LENGTH_LONG).show()
                finish()
            }
    }

    @Deprecated("Android system consent result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Screen analysis was cancelled", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val service = Intent(this, ScreenCaptureService::class.java)
            .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        runCatching { ContextCompat.startForegroundService(this, service) }
            .onFailure { Toast.makeText(this, "Couldn't start secure screen capture: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
        finish()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(STATE_REQUESTED, requested)
        super.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_CAPTURE = 918
        private const val STATE_REQUESTED = "capture_requested"
    }
}
