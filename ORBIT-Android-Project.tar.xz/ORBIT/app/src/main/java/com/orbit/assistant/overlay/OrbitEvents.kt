package com.orbit.assistant.overlay

object OrbitEvents {
    const val ACTION_VOICE_RESULT = "com.orbit.assistant.action.VOICE_RESULT"
    const val ACTION_SCREEN_RESULT = "com.orbit.assistant.action.SCREEN_RESULT"
    const val ACTION_IMAGE_RESULT = "com.orbit.assistant.action.IMAGE_RESULT"
    const val EXTRA_TRANSCRIPT = "transcript"
    const val EXTRA_SCREEN_JPEG = "screen_jpeg"
}
