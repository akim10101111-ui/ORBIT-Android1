package com.orbit.assistant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Lightweight native view version of the ORBIT white four-point mark for overlays. */
class OrbitMarkView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val mark = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = minOf(width, height).toFloat()
        val left = (width - s) / 2f
        val top = (height - s) / 2f
        canvas.save()
        canvas.translate(left, top)
        canvas.scale(s, s)
        mark.reset()
        mark.moveTo(.51f, .05f)
        mark.cubicTo(.47f, .25f, .38f, .46f, .28f, .49f)
        mark.cubicTo(.14f, .52f, .02f, .38f, .06f, .31f)
        mark.cubicTo(.03f, .24f, .11f, .20f, .23f, .27f)
        mark.cubicTo(.39f, .35f, .44f, .39f, .49f, .34f)
        mark.cubicTo(.55f, .29f, .66f, .13f, .76f, .06f)
        mark.cubicTo(.82f, .01f, .85f, .03f, .80f, .12f)
        mark.cubicTo(.72f, .31f, .67f, .43f, .72f, .51f)
        mark.cubicTo(.78f, .60f, .92f, .68f, .88f, .76f)
        mark.cubicTo(.84f, .84f, .70f, .79f, .60f, .70f)
        mark.cubicTo(.49f, .62f, .43f, .60f, .36f, .68f)
        mark.cubicTo(.25f, .77f, .13f, .95f, .08f, .89f)
        mark.cubicTo(.02f, .83f, .15f, .63f, .22f, .54f)
        mark.cubicTo(.28f, .46f, .25f, .41f, .18f, .35f)
        mark.cubicTo(.10f, .28f, .10f, .24f, .15f, .21f)
        mark.cubicTo(.22f, .18f, .35f, .29f, .42f, .35f)
        mark.cubicTo(.48f, .40f, .52f, .28f, .51f, .05f)
        mark.close()
        canvas.drawPath(mark, paint)
        val sparkle = Path().apply {
            moveTo(.89f, .43f); cubicTo(.91f, .49f, .93f, .52f, .96f, .53f)
            cubicTo(.93f, .55f, .91f, .59f, .89f, .65f)
            cubicTo(.87f, .59f, .85f, .55f, .82f, .53f)
            cubicTo(.85f, .51f, .87f, .49f, .89f, .43f); close()
        }
        canvas.drawPath(sparkle, paint)
        canvas.restore()
    }
}
