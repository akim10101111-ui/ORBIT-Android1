package com.orbit.assistant.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.orbit.assistant.OrbitPrefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import java.util.concurrent.Executors

/** Gemini REST client. Requests run off the UI thread; callbacks are always delivered on main. */
object GeminiClient {
    const val MODEL = "gemini-3.8-flash"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
    private val io = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun reply(
        context: Context,
        prompt: String,
        imageJpeg: ByteArray? = null,
        callback: (String) -> Unit
    ) {
        val app = context.applicationContext
        io.execute {
            val answer = runCatching { execute(app, prompt, imageJpeg) }
                .getOrElse { GeminiErrors.forNetworkFailure(it) }
            main.post { callback(answer) }
        }
    }

    private fun execute(context: Context, prompt: String, imageJpeg: ByteArray?): String {
        val key = OrbitPrefs.getKey(context)
        if (key.isBlank()) return "Add your Gemini API key in ORBIT settings before sending a message."
        if (prompt.isBlank()) return "Write or say a question first."
        if (imageJpeg != null && imageJpeg.size > 5 * 1024 * 1024) {
            return "The attached image is too large. Capture the screen again or choose a smaller image."
        }

        val parts = JSONArray().put(JSONObject().put("text", prompt.trim()))
        imageJpeg?.let { bytes ->
            parts.put(JSONObject().put("inlineData", JSONObject()
                .put("mimeType", "image/jpeg")
                .put("data", Base64.getEncoder().encodeToString(bytes))))
        }
        val systemPrompt = "You are ORBIT, a helpful Android screen companion. Reply in the user's language, " +
            "usually Russian when the user speaks Russian. Be concise, warm and practical. " +
            "When an image is attached, analyze only what is visibly present. A single screenshot is not a full video: " +
            "never claim to have watched audio, earlier frames, or the whole video. Clearly state uncertainty. " +
            "Never claim to control the device or see the screen unless an image was supplied."
        val payload = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 900))

        val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use(BufferedReader::readText)
            }.orEmpty()
            if (status !in 200..299) {
                val detail = runCatching {
                    JSONObject(responseText).optJSONObject("error")?.optString("message").orEmpty()
                }.getOrDefault("")
                return GeminiErrors.forHttpCode(status, detail)
            }
            val response = runCatching { JSONObject(responseText) }.getOrElse {
                return "Gemini returned an unreadable response. Please try again."
            }
            val candidates = response.optJSONArray("candidates")
            val contentParts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val text = buildString {
                for (index in 0 until (contentParts?.length() ?: 0)) {
                    val piece = contentParts?.optJSONObject(index)?.optString("text").orEmpty()
                    if (piece.isNotBlank()) {
                        if (isNotEmpty()) append('\n')
                        append(piece)
                    }
                }
            }.trim()
            if (text.isNotEmpty()) return text
            val reason = candidates?.optJSONObject(0)?.optString("finishReason").orEmpty()
            return when (reason) {
                "SAFETY" -> "Gemini couldn't provide this response because the request was blocked by its safety filters."
                "MAX_TOKENS" -> "The response was cut off. Ask ORBIT to continue."
                "RECITATION" -> "Gemini couldn't complete this answer because of a source-content restriction. Try a different question."
                else -> "Gemini returned an empty answer. Please rephrase the question and try again."
            }
        } finally {
            connection.disconnect()
        }
    }
}
