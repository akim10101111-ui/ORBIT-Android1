package com.orbit.assistant.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.content.pm.ServiceInfo
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** Captures exactly one user-approved frame, then immediately releases projection resources. */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val main = Handler(Looper.getMainLooper())
    private val completed = AtomicBoolean(false)
    private val cleaning = AtomicBoolean(false)
    private var timeout: Runnable? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode != RESULT_OK_VALUE || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        cleaning.set(false)
        completed.set(false)
        runCatching { startCaptureForeground(); beginOneShotCapture(resultCode, resultData) }
            .onFailure {
                notifyFailure("Screen capture failed: ${it.localizedMessage ?: "permission or device restriction"}")
                cleanup()
            }
        return START_NOT_STICKY
    }

    private fun startCaptureForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "ORBIT screen analysis", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ORBIT is analyzing one screen frame")
            .setContentText("Screen capture stops automatically after the snapshot")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun beginOneShotCapture(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mediaProjection = manager.getMediaProjection(resultCode, data)
        projection = mediaProjection
        mediaProjection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { cleanup() }
        }, main)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ source ->
            if (completed.get()) return@setOnImageAvailableListener
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            runCatching { encodeImage(image, width, height) }
                .onSuccess { bytes ->
                    if (completed.compareAndSet(false, true)) {
                        sendBroadcast(Intent(OrbitEvents.ACTION_SCREEN_RESULT)
                            .setPackage(packageName)
                            .putExtra(OrbitEvents.EXTRA_SCREEN_JPEG, bytes))
                        Toast.makeText(this, "Screen snapshot attached to ORBIT", Toast.LENGTH_SHORT).show()
                    }
                }
                .onFailure { notifyFailure("Couldn't read the screen frame: ${it.localizedMessage}") }
                .also { image.close(); cleanup() }
        }, main)

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "ORBIT one-shot screen snapshot", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, main
        )
        timeout = Runnable {
            if (!completed.get()) notifyFailure("No screen frame arrived. Try again or check whether this app blocks screenshots.")
            cleanup()
        }.also { main.postDelayed(it, 4_000L) }
    }

    private fun encodeImage(image: Image, screenWidth: Int, screenHeight: Int): ByteArray {
        val plane = image.planes.first()
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = screenWidth + (rowStride - pixelStride * screenWidth) / pixelStride
        val raw = Bitmap.createBitmap(paddedWidth, screenHeight, Bitmap.Config.ARGB_8888)
        try {
            buffer.rewind()
            raw.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(raw, 0, 0, screenWidth, screenHeight)
            try {
                val targetWidth = minOf(cropped.width, 1280)
                val targetHeight = (cropped.height * targetWidth.toFloat() / cropped.width).toInt().coerceAtLeast(1)
                val scaled = if (targetWidth == cropped.width) cropped else Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
                try {
                    return ByteArrayOutputStream().use { output ->
                        scaled.compress(Bitmap.CompressFormat.JPEG, 78, output)
                        output.toByteArray()
                    }
                } finally {
                    if (scaled !== cropped) scaled.recycle()
                }
            } finally { cropped.recycle() }
        } finally { raw.recycle() }
    }

    private fun notifyFailure(message: String) {
        main.post { Toast.makeText(this, message.take(180), Toast.LENGTH_LONG).show() }
    }

    private fun cleanup() {
        if (!cleaning.compareAndSet(false, true)) return
        timeout?.let(main::removeCallbacks)
        timeout = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { projection?.stop() }
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { cleanupResourcesOnly(); super.onDestroy() }
    private fun cleanupResourcesOnly() {
        timeout?.let(main::removeCallbacks)
        runCatching { virtualDisplay?.release() }; virtualDisplay = null
        runCatching { imageReader?.close() }; imageReader = null
        val activeProjection = projection
        projection = null
        runCatching { activeProjection?.stop() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val RESULT_OK_VALUE = -1
        private const val CHANNEL_ID = "orbit_capture"
        private const val NOTIFICATION_ID = 43
    }
}
