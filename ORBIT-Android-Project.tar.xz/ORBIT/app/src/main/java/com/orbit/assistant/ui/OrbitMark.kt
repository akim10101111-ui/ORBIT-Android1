package com.orbit.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate

/** Custom ORBIT mark inspired by the user's reference: a rounded, asymmetrical four-point star + sparkle. */
@Composable
fun OrbitMark(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val main = Path().apply {
            moveTo(w*.51f, h*.05f)
            cubicTo(w*.47f, h*.25f, w*.38f, h*.46f, w*.28f, h*.49f)
            cubicTo(w*.14f, h*.52f, w*.02f, h*.38f, w*.06f, h*.31f)
            cubicTo(w*.03f, h*.24f, w*.11f, h*.20f, w*.23f, h*.27f)
            cubicTo(w*.39f, h*.35f, w*.44f, h*.39f, w*.49f, h*.34f)
            cubicTo(w*.55f, h*.29f, w*.66f, h*.13f, w*.76f, h*.06f)
            cubicTo(w*.82f, h*.01f, w*.85f, h*.03f, w*.80f, h*.12f)
            cubicTo(w*.72f, h*.31f, w*.67f, h*.43f, w*.72f, h*.51f)
            cubicTo(w*.78f, h*.60f, w*.92f, h*.68f, w*.88f, h*.76f)
            cubicTo(w*.84f, h*.84f, w*.70f, h*.79f, w*.60f, h*.70f)
            cubicTo(w*.49f, h*.62f, w*.43f, h*.60f, w*.36f, h*.68f)
            cubicTo(w*.25f, h*.77f, w*.13f, h*.95f, w*.08f, h*.89f)
            cubicTo(w*.02f, h*.83f, w*.15f, h*.63f, w*.22f, h*.54f)
            cubicTo(w*.28f, h*.46f, w*.25f, h*.41f, w*.18f, h*.35f)
            cubicTo(w*.10f, h*.28f, w*.10f, h*.24f, w*.15f, h*.21f)
            cubicTo(w*.22f, h*.18f, w*.35f, h*.29f, w*.42f, h*.35f)
            cubicTo(w*.48f, h*.40f, w*.52f, h*.28f, w*.51f, h*.05f)
            close()
        }
        drawPath(main, Color.White)
        val sparkle = Path().apply {
            moveTo(w*.89f, h*.43f); cubicTo(w*.91f,h*.49f,w*.93f,h*.52f,w*.96f,h*.53f)
            cubicTo(w*.93f,h*.55f,w*.91f,h*.59f,w*.89f,h*.65f)
            cubicTo(w*.87f,h*.59f,w*.85f,h*.55f,w*.82f,h*.53f)
            cubicTo(w*.85f,h*.51f,w*.87f,h*.49f,w*.89f,h*.43f); close()
        }
        drawPath(sparkle, Color.White)
    }
}
