package com.orbit.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.orbit.assistant.overlay.OrbitOverlayService
import com.orbit.assistant.ui.OrbitMark

private val Background = Color(0xFF060608)
private val SurfaceDark = Color(0xFF111116)
private val SurfaceRaised = Color(0xFF19191F)
private val Stroke = Color(0xFF292932)
private val Muted = Color(0xFF9696A2)
private val Lavender = Color(0xFFB8A1FF)
private val Cyan = Color(0xFF79D8F2)

class MainActivity : ComponentActivity() {
    private val overlayAllowed = mutableStateOf(false)

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        // A foreground service must always show its notification, but Android permits starting
        // it even when the notification runtime permission is denied.
        startOverlayService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overlayAllowed.value = Settings.canDrawOverlays(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Background,
                surface = SurfaceDark,
                primary = Lavender,
                onBackground = Color.White,
                onSurface = Color.White
            )) {
                OrbitHome(
                    overlayAllowed = overlayAllowed.value,
                    apiKey = OrbitPrefs.getKey(this),
                    onSaveKey = { value ->
                        val saved = OrbitPrefs.setKey(this, value)
                        if (!saved) Toast.makeText(this, "Secure storage is unavailable on this device", Toast.LENGTH_LONG).show()
                    },
                    onStart = ::requestAndStartOverlay,
                    onGrantOverlay = ::openOverlaySettings
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        overlayAllowed.value = Settings.canDrawOverlays(this)
    }

    private fun requestAndStartOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else startOverlayService()
    }

    private fun openOverlaySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }.onFailure {
            Toast.makeText(this, "Open Android Settings and allow 'Display over other apps' for ORBIT", Toast.LENGTH_LONG).show()
        }
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow ORBIT to display over other apps first", Toast.LENGTH_LONG).show()
            return
        }
        runCatching {
            ContextCompat.startForegroundService(this, Intent(this, OrbitOverlayService::class.java))
            Toast.makeText(this, "ORBIT is ready above your apps", Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(this, "Couldn't start ORBIT: ${it.localizedMessage ?: "system restriction"}", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
private fun OrbitHome(
    overlayAllowed: Boolean,
    apiKey: String,
    onSaveKey: (String) -> Unit,
    onStart: () -> Unit,
    onGrantOverlay: () -> Unit
) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    var revealKey by remember { mutableStateOf(false) }
    val pulse = rememberInfiniteTransition(label = "orb pulse")
    val orbScale by pulse.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Reverse),
        label = "orb scale"
    )

    Column(
        modifier = Modifier.fillMaxSize()
            .background(Background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 18.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(48.dp).background(SurfaceRaised, CircleShape).border(1.dp, Stroke, CircleShape), contentAlignment = Alignment.Center) {
                OrbitMark(Modifier.size(31.dp))
            }
            Column {
                Text("ORBIT", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("YOUR AI, JUST AROUND THE CORNER", color = Muted, fontSize = 9.sp, letterSpacing = 1.25.sp)
            }
            Spacer(Modifier.weight(1f))
            StatusPill(if (overlayAllowed) "READY" else "SETUP", overlayAllowed)
        }

        Box(
            Modifier.fillMaxWidth().height(270.dp)
                .background(Brush.radialGradient(listOf(Color(0x333F4B84), Color(0x1E343052), Background))),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(224.dp).scale(orbScale).background(
                Brush.radialGradient(listOf(Color(0x264F8FFF), Color(0x1C9B75E8), Color.Transparent)), CircleShape
            ), contentAlignment = Alignment.Center) {
                Box(Modifier.size(158.dp).background(Color(0xFF101015), CircleShape)
                    .border(1.dp, Color(0xFF393545), CircleShape), contentAlignment = Alignment.Center) {
                    OrbitMark(Modifier.size(96.dp))
                }
            }
            Column(Modifier.align(Alignment.BottomCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Intelligence, within reach.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                Text("A small assistant. A bigger picture.", color = Muted, fontSize = 13.sp)
            }
        }

        Surface(color = SurfaceDark, shape = RoundedCornerShape(27.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Stroke)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("FLOATING ASSISTANT", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (overlayAllowed) "✓" else "◎",
                        color = if (overlayAllowed) Color(0xFF72D6B1) else Lavender,
                        fontSize = 17.sp, modifier = Modifier.size(18.dp))
                }
                Text(if (overlayAllowed) "Ready to appear over your apps" else "One permission to get started",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Open YouTube, a browser or a game. ORBIT stays as a small orb until you call it.",
                    color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF111116))
                ) {
                    Text(if (overlayAllowed) "Launch floating ORBIT" else "Enable floating access", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp)); Text("→", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                if (!overlayAllowed) {
                    TextButton(onClick = onGrantOverlay, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("Open Android permission settings", color = Lavender, fontSize = 12.sp)
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            FeatureCard("SCREEN VISION", "Ask about what is visible", "◎", Modifier.weight(1f))
            FeatureCard("VOICE", "Speak instead of typing", "◖", Modifier.weight(1f))
        }

        Surface(color = SurfaceDark, shape = RoundedCornerShape(25.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Stroke)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("◇", color = Lavender, fontSize = 21.sp, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(9.dp))
                    Text("AI CONNECTION", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("GEMINI", color = Lavender, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                }
                Text("Gemini 3.8 Flash · text + image understanding", color = Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; onSaveKey(it) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Gemini API key") },
                    placeholder = { Text("Paste your API key") },
                    singleLine = true,
                    visualTransformation = if (revealKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { revealKey = !revealKey }) { Text(if (revealKey) "HIDE" else "SHOW", color = Muted, fontSize = 10.sp) } },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = Lavender, unfocusedBorderColor = Stroke,
                        focusedLabelColor = Lavender, unfocusedLabelColor = Muted,
                        cursorColor = Lavender
                    )
                )
                Text("Stored encrypted on this device. Never upload your key to GitHub.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⌁", color = Cyan, fontSize = 16.sp, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("Internet is required for Gemini replies.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { key = ""; onSaveKey("") }) { Text("CLEAR KEY", color = Color(0xFFC0B9D4), fontSize = 10.sp) }
                }
            }
        }

        Text("PRIVATE BY DESIGN  ·  Screen capture starts only after you tap the button and approve Android's system prompt.",
            color = Color(0xFF696975), fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.alpha(0.95f))
    }
}

@Composable
private fun StatusPill(label: String, active: Boolean) {
    val color = if (active) Color(0xFF72D6B1) else Lavender
    Box(Modifier.background(color.copy(alpha = 0.09f), CircleShape).border(1.dp, color.copy(alpha = 0.28f), CircleShape).padding(horizontal = 12.dp, vertical = 7.dp)) {
        Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = SurfaceDark, shape = RoundedCornerShape(21.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Stroke)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(icon, color = Lavender, fontSize = 22.sp, modifier = Modifier.size(20.dp))
            Text(title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}
