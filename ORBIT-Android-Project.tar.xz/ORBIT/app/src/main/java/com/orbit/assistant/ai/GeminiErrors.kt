package com.orbit.assistant.ai

/** Human-readable error messages shared by network code and unit tests. */
internal object GeminiErrors {
    fun forHttpCode(code: Int, detail: String = ""): String {
        val suffix = detail.trim().takeIf { it.isNotEmpty() }?.let { "\n\nDetails: $it" }.orEmpty()
        return when (code) {
            400 -> "Gemini couldn't process this request. Try a shorter question or capture the screen again.$suffix"
            401, 403 -> "The Gemini API key is invalid or doesn't have access. Check the key in ORBIT settings."
            404 -> "The selected Gemini model or API endpoint wasn't found. Update ORBIT to the latest model configuration."
            408 -> "The request timed out. Check your connection and try again."
            429 -> "Gemini rate limit or free-tier quota reached. Wait a little and try again."
            in 500..599 -> "Gemini is temporarily unavailable (HTTP $code). Try again in a moment."
            else -> "Gemini request failed (HTTP $code). Try again. $suffix".trim()
        }
    }

    fun forNetworkFailure(error: Throwable): String = when (error) {
        is java.net.UnknownHostException -> "No internet connection. Connect to Wi-Fi or mobile data and try again."
        is java.net.SocketTimeoutException -> "The connection is taking too long. Check your internet and try again."
        is javax.net.ssl.SSLException -> "A secure connection couldn't be established. Check your date, time and network, then retry."
        is java.io.IOException -> "Network error. Check your internet connection and try again."
        else -> "Something went wrong. Please try again."
    }
}
