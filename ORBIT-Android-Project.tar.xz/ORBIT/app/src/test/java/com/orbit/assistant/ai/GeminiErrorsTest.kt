package com.orbit.assistant.ai

import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiErrorsTest {
    @Test fun unauthorizedExplainsApiKey() {
        assertTrue(GeminiErrors.forHttpCode(401).contains("API key"))
    }

    @Test fun forbiddenExplainsApiKeyAccess() {
        assertTrue(GeminiErrors.forHttpCode(403).contains("access"))
    }

    @Test fun quotaErrorIsActionable() {
        assertTrue(GeminiErrors.forHttpCode(429).contains("quota"))
    }

    @Test fun serverErrorIsRetryable() {
        assertTrue(GeminiErrors.forHttpCode(503).contains("temporarily unavailable"))
    }

    @Test fun networkErrorExplainsConnection() {
        assertTrue(GeminiErrors.forNetworkFailure(java.net.UnknownHostException()).contains("No internet connection"))
    }
}
